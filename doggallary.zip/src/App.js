
import List from './api/List';




function App() {
  return (
    <>
   
    <List/>

    
    
    
    
    </>
  );
}


export default App;
